import '../styles/globals.css'
import Navbar from '../src/app/components/navbar'
import Footer from '../src/app/components/footer'

function MyApp({ Component, pageProps }) {
  return <>
      {/* <Navbar/> */}
  <Component {...pageProps} />
    
  </>
}

export default MyApp
