import './globals.css'
import Navbar from './components/navbar'
import Footer from './components/footer'
import Home from './index'

function MyApp({ Component, pageProps }) {
  return <>
      {/* <Navbar/> */}
      <Home></Home>
  {/* <Component {...pageProps} /> */}
    
  </>
}

export default MyApp
